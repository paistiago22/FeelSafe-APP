package pt.ubi.di.sdfsdf;

import androidx.annotation.NonNull;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hbb20.CountryCodePicker;

import java.security.NoSuchAlgorithmException;

public class Registar extends Activity {


    EditText Name,Code,Password,contacto1,contacto2,Nome1,Nome2;
    Button formRegisterButton;
    TextView auxTextView;
    ImageView im;
    Integer count=0,count2=0,t2,t3;
    private CountryCodePicker r1;
    private CountryCodePicker r2;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    Users use = new Users();

    int u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_registar);

        formRegisterButton = findViewById(R.id.form);
        im = findViewById(R.id.goBackImageRegister);

        Name = findViewById(R.id.Nome);
        Code = findViewById(R.id.Code);
        Password = findViewById(R.id.Password);
        contacto1 = findViewById(R.id.Contacto1);
        contacto2 = findViewById(R.id.Contacto2);
        Nome1 = findViewById(R.id.nome1Pess);
        Nome2 = findViewById(R.id.nome2Pess);
        r1 = findViewById(R.id.countryCode_picker1);
        r2 = findViewById(R.id.countryCode_picker2);

        Code.setVisibility(View.INVISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getLastId();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String name = preferences.getString("Name", "");
        if(name!=""){
            u = Integer.parseInt(name);
            System.out.println(u);
        }



        formRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String q,e,q1,q2;
                Integer t,y,w;
                q = Name.getText().toString();
                q1 = Nome1.getText().toString();
                q2 = Nome2.getText().toString();

                e = Password.getText().toString();

                if(contacto1.getText().toString().equals("")){
                    t = 0;
                }else{
                    t = Integer.parseInt(contacto1.getText().toString());
                }


                w = 0;


                if(contacto2.getText().toString().equals("")){
                    y = 0;
                }else{
                    y = Integer.parseInt(contacto2.getText().toString());
                }


                if(q.equals("") || q2.equals("") || q1.equals("")|| e.equals("") || t ==0 || y==0){
                    Toast.makeText(Registar.this, "Dados incompletos", Toast.LENGTH_SHORT).show();


                    GradientDrawable gdf = new GradientDrawable();
                    gdf.setColor(Color.parseColor("#00ffffff"));
                    gdf.setStroke(2,Color.WHITE);
                    Name.setBackground(gdf);
                    Nome1.setBackground(gdf);
                    Nome2.setBackground(gdf);
                    Password.setBackground(gdf);
                    //Code.setBackground(gdf);
                    contacto1.setBackground(gdf);
                    contacto2.setBackground(gdf);

                    if (q.equals("")){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        Name.setBackground(gd);
                    }

                    if (Nome1.getText().toString().equals("")){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        Nome1.setBackground(gd);
                    }
                    if (Nome2.getText().toString().equals("")){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        Nome2.setBackground(gd);
                    }
                    if (Password.getText().toString().equals("")){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        Password.setBackground(gd);
                    }/*
                    if (Code.getText().toString().equals("")){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        Code.setBackground(gd);
                    }*/
                    if (t==0){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        contacto1.setBackground(gd);
                    }
                    if (y==0){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        contacto2.setBackground(gd);
                    }
                }else{
                    use.setNome(q);

                    byte[] salt = new byte[10];
                    String d="";

                    try {
                        d = Hash_Help.getSalt1();
                        use.setSal(d);
                        System.out.println("tou ca");
                    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                        noSuchAlgorithmException.printStackTrace();
                    }

                    salt = d.getBytes();
                    String password1 = Hash_Help.getSecurePassword(e, salt);

                    String code = r1.getSelectedCountryCode();
                    System.out.println(code);

                    String code2 = r2.getSelectedCountryCode();
                    System.out.println(code2);

                    String h1 = code + t.toString();
                    System.out.println(h1);

                    String h2 = code2 + y.toString();
                    System.out.println(h2);

                    int re = 0,ree = 0;
                    double str2=0,str1=0;


                    try{
                        str1 = Double.parseDouble(h1);
                        str2 = Double.parseDouble(h2);
                    } catch(NumberFormatException ex){ // handle your exception
                        System.out.println("ola");
                    }

                    use.setPass(password1);
                    use.setCodigo(w);
                    use.setCon1(str1);
                    use.setCont2(str2);
                    use.setName1(q1);
                    use.setName2(q2);
                    System.out.println("asdasdasd00.ola");
                    addDatatoFirebase(use);
                }
            }
        });
    }


    private void addDatatoFirebase(Users a) {
        //verificar credenciais na base de dados

        String p = "Users/" + a.getNome();
        databaseReference = firebaseDatabase.getReference(p);
        final boolean[] r = new boolean[1];
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            boolean verify = true;
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    Toast.makeText(Registar.this, "Ja existe o UserName", Toast.LENGTH_SHORT).show();
                    verify = false;
                    r[0] = verify;
                } else {
                    Toast.makeText(Registar.this, "Sucesso", Toast.LENGTH_SHORT).show();
                    databaseReference.setValue(a);
                    r[0] = verify;
                    goatras();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    public void goatras(View v){
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    public void goatras(){
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }


    public void getLastId(){


        firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
        //String p = "User";
        //databaseReference = firebaseDatabase.getReference(p);
/*




        databaseReference.addChildEventListener(new ChildEventListener() {

            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                User user = dataSnapshot.getValue(User.class);
                if(user.getId() > Integer.parseInt(auxTextView.getText().toString())){
                    auxTextView.setText(user.getId() + "");
                }

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) { }
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) { }
            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) { }
            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });

*/
    }}

