package pt.ubi.di.sdfsdf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class Menu_Projeto extends AppCompatActivity {

    Button Button_def,Button_Help,Button_Mapa,Button_sair,Button;
    Switch aSwitch;
    //String valor;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private SQLiteDatabase sql;
    private AjudaBaseDados ajudante;

    private SQLiteDatabase sql1;
    private Dados ajudante1;

    String nome1,nome2,palavra;
    long contacto1;
    long contacto2;


    private GpsTracker gpsTracker;
    private GpsTracker gpsTracker1;
    private GpsTracker gpsTracker2;
    private GpsTracker gpsTracker3;
    List<LatLng> result = new ArrayList<LatLng>();
    List<LateLOng> result1 = new ArrayList<LateLOng>();
    double latitude=0;
    double longitude=0;
    Users a = new Users();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_projeto);

        ajudante1 = new Dados(this);
        sql1 = ajudante1.getReadableDatabase();
        ajudante1.onCreate(sql1);

        boolean h = false;

        try(Cursor c = sql.rawQuery("SELECT * FROM INFOUSERR ", null)){ // VER SE A BASE DE DADOS EXISTE
            c.moveToNext();
            String mat = c.getString(0);
            int a = Integer.parseInt(mat);
            if(a == 1){
                h = true;
            }
        }catch(RuntimeException err){
            System.out.println("deu erro");
        }


/*
        if (!h){ //SE NAO EXISTIR, INSERIR OS DADOS
            sql1.execSQL("INSERT INTO INFOUSERR VALUES('Maria',+351918391571,'Raul',+351919969022,'Fui Compras',1)");
        }
*/


        Button_def = (Button) findViewById(R.id.button3);
        Button_Help = (Button) findViewById(R.id.button);
        Button_Mapa = (Button) findViewById(R.id.button2);
        Button_sair = (Button) findViewById(R.id.button55);
        //Button = (Button) findViewById(R.id.button22);
        aSwitch = (Switch) findViewById(R.id.switch1);


        ajudante = new AjudaBaseDados(this);
        sql = ajudante.getReadableDatabase();
        ajudante.onCreate(sql);



        ler();
        ler1();

        System.out.println(a.getCon1());
    }



    public void showSettingsAlert1(){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Menu_Projeto.this);

        // Setting Dialog Title
        alertDialog.setTitle("Permissões");

        // Setting Dialog Message
        alertDialog.setMessage("\n"+"Não tenho todas Permissões necessarias");

        // On pressing Settings button
        /*
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                mContext.startActivity(intent);
            }
        });
*/
        // on pressing cancel button
        alertDialog.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    public void showSettingsAlert2(){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Menu_Projeto.this);

        // Setting Dialog Title
        alertDialog.setTitle("Localizacao");

        // Setting Dialog Message
        alertDialog.setMessage("\n"+"Não tenho acesso");

        // On pressing Settings button
        /*
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                mContext.startActivity(intent);
            }
        });
*/
        // on pressing cancel button
        alertDialog.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }


    @Override
    protected void onResume() {
        super.onResume();
        //getLocation();
        //valor =  (String) getIntent().getSerializableExtra("edit");


        //System.out.println("pqdqdqd"+(ContextCompat.checkSelfPermission(Menu_Projeto.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED));


        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if((ContextCompat.checkSelfPermission(Menu_Projeto.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)){

                    gpsTracker3 = new GpsTracker(Menu_Projeto.this);
                    if(gpsTracker3.canGetLocation()){
                        if(isChecked){
                            Intent ttttq = new Intent(getBaseContext(), Servico_Notificacoes.class);
                            getLocation();
                            ttttq.putExtra("nome", (ArrayList<LateLOng>) result1);
                            startService(ttttq);
                        }else{
                            System.out.println("xau");
                            stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));
                        }
                    }
                    else{
                        aSwitch.setChecked(false);
                        showSettingsAlert2();
                    }
                }else{
                    aSwitch.setChecked(false);
                    showSettingsAlert1();
                }
            }
        });

        Button_def.setOnClickListener(v -> {
            Intent tt = new Intent(getBaseContext(),Defenicao_Projeto.class);
            //tt.putExtra("nome",valor);
            startActivity(tt);
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
        });

        Button_Mapa.setOnClickListener(v -> {

                gpsTracker2 = new GpsTracker(Menu_Projeto.this);
                //if(gpsTracker2.canGetLocation()){

                    //Button.setText("COMECAR");
                    stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));
                    aSwitch.setChecked(false);
                    if(gpsTracker2.canGetLocation()){
                        getLocation();
                    }


                    System.out.println("Aqui");

                    System.out.println(result.toString());

                    Intent tttt = new Intent(getBaseContext(),MapsActivity6.class);
                    tttt.putExtra("nome", (ArrayList<LatLng>) result);
                    tttt.putExtra("la",latitude);
                    tttt.putExtra("lo",longitude);
                    startActivity(tttt);
                //}else{
                  //  showSettingsAlert2();
                //}

        });
/*
        Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Button.getText().toString().equals("COMECAR")){
                    Button.setText("CANCELAR");
                    System.out.println("aqui");
                    Intent ttttq = new Intent(getBaseContext(),MyService.class);
                    getLocation();
                    ttttq.putExtra("nome", (ArrayList<LateLOng>) result1);

                    startService(ttttq);
                    //startService(new Intent(getBaseContext(), MyService.class));
                }else{
                    Button.setText("COMECAR");
                    stopService(new Intent(getBaseContext(), MyService.class));
                }
            }
        });
*/

        Button_sair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Button.setText("COMECAR");
                stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));

                goatras();
            }

        });






        Button_Help.setOnClickListener(v -> {
            //verificar credenciais na base de dados

            if((ContextCompat.checkSelfPermission(Menu_Projeto.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Menu_Projeto.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Menu_Projeto.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Menu_Projeto.this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Menu_Projeto.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)){

                gpsTracker1 = new GpsTracker(Menu_Projeto.this);

                    /*
                    String pp = "Users/" + valor;
                    firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
                    databaseReference = firebaseDatabase.getReference(pp);
                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        boolean verify = true;
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists()){
                                System.out.println("EXISTS");
                                databaseReference.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        System.out.println("EXISTS");
                                        Users users = snapshot.getValue(Users.class);
                                        Users d = users;

                                        //Button.setText("COMECAR");
                                        stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));
                                        aSwitch.setChecked(false);


                                        System.out.println(contacto1);
                                        System.out.println(contacto2);


                                        Intent ttt = new Intent(getBaseContext(),Ajuda_Projeto.class);
                                        ttt.putExtra("nome1",d.getName1());
                                        ttt.putExtra("con1",d.getCon1());
                                        ttt.putExtra("nome2",d.getName2());
                                        ttt.putExtra("con2",d.getCont2());
                                        ttt.putExtra("palavra",d.getPalavra());
                                        startActivity(ttt);
                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                    */


                ler1();
                //Button.setText("COMECAR");
                stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));
                aSwitch.setChecked(false);

                System.out.println(contacto1);
                System.out.println(contacto2);

                if( !((nome1.equals("") || contacto1 == 0) || (nome2.equals("") || contacto2 == 0)) ){
                    Intent ttt = new Intent(getBaseContext(),Ajuda_Projeto.class);
                    ttt.putExtra("nome1",nome1);
                    ttt.putExtra("con1",contacto1);
                    ttt.putExtra("nome2",nome2);
                    ttt.putExtra("con2",contacto2);
                    ttt.putExtra("palavra",palavra);
                    startActivity(ttt);
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                }
/*
                Intent ttt = new Intent(getBaseContext(),Ajuda_Projeto.class);
                ttt.putExtra("nome1",nome1);
                ttt.putExtra("con1",contacto1);
                ttt.putExtra("nome2",nome2);
                ttt.putExtra("con2",contacto2);
                ttt.putExtra("palavra",palavra);
                startActivity(ttt);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
*/
            }else{
                showSettingsAlert1();
            }
        });
    }

    public void ler(){
        try(Cursor c = sql.rawQuery("SELECT * FROM INFO ", null)){
            boolean conteudo = c.moveToFirst();
            //System.out.println(conteudo);
            while (conteudo) {
                double s = c.getDouble(0);
                double s1 = c.getDouble(1);
                result.add(new LatLng(s, s1));
                result1.add(new LateLOng(s,s1));
                conteudo = c.moveToNext();
                //System.out.println(conteudo);
            }
            //System.out.println(result);
        }catch(RuntimeException e){
            System.out.println(e);
        }
    }


    public void ler1(){
        System.out.println("=====");
        try(Cursor c = sql.rawQuery("SELECT * FROM INFOUSERR ", null)){
            boolean conteudo = c.moveToFirst();
            while (conteudo) {
                String s = c.getString(0);
                Double s1 = c.getDouble(1);
                String s2 = c.getString(2);
                Double s3 = c.getDouble(3);
                String s4 = c.getString(4);

                System.out.println("ola");


                //Double k = Double.parseDouble(s1);
                //System.out.println(s1);
                //System.out.println("+"+ Double.valueOf(s1).longValue());

                //contacto1 = "+" + Double.valueOf(s1).longValue();
                //contacto2 = "+" + Double.valueOf(s3).longValue();
                contacto1 = Double.valueOf(s1).longValue();
                contacto2 = Double.valueOf(s3).longValue();
                nome1 = s;
                nome2 = s2;
                palavra = s4;

                System.out.println(contacto1);
                System.out.println(contacto2);

/*
                a.setPalavra(s4);
                a.setName2(s2);
                a.setName1(s);
                a.setCon1(s1);
                a.setCont2(s3);
                System.out.println("------------------------------------------");
                System.out.println(a);
*/

                conteudo = c.moveToNext();
                //System.out.println(conteudo);
            }
            //System.out.println(result);
        }catch(RuntimeException e){
            System.out.println(e);
        }
    }



    private void addDatatoFirebase(String j, LateLOng i) {
        //verificar credenciais na base de dados
        firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
        String p = "Local/" + j;
        databaseReference = firebaseDatabase.getReference(p);
        final boolean[] r = new boolean[1];
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            boolean verify = true;
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    //Toast.makeText(Ajuda_Projeto.this, "Ja existe o UserName", Toast.LENGTH_SHORT).show();
                    verify = false;
                    r[0] = verify;
                } else {
                    //Toast.makeText(Ajuda_Projeto.this, "Sucesso", Toast.LENGTH_SHORT).show();
                    databaseReference.setValue(i);
                    r[0] = verify;
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }


    public void getLocation(){
        gpsTracker = new GpsTracker(Menu_Projeto.this);
        if(gpsTracker.canGetLocation()){
            latitude = gpsTracker.getLatitude();
            longitude = gpsTracker.getLongitude();
        }else{
            gpsTracker.showSettingsAlert();
        }
    }


    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(Menu_Projeto.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Deseja sair?")
                .setCancelable(false)
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        //Button.setText("COMECAR");
                        stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));

                        Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        startActivity(intent);
                        //finishAndRemoveTask();
                    }
                })
                .setNegativeButton("Nao", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }

    public void goatras(){
        onBackPressed();
    }

    @Override
    public void finish() {
        onBackPressed();
    }

}







