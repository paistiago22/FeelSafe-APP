package pt.ubi.di.sdfsdf;

import java.io.Serializable;

public class Users implements Serializable {
    private String Nome;
    private String Pass;
    private String Sal;
    private double Con1;
    private double Cont2;
    private int Codigo;
    private String Name1;
    private String Name2;
    private String palavra;



    @Override
    public String toString() {
        return "Users{" +
                "Nome='" + Nome + '\'' +
                ", Pass='" + Pass + '\'' +
                ", Sal='" + Sal + '\'' +
                ", Con1=" + Con1 +
                ", Cont2=" + Cont2 +
                ", Codigo=" + Codigo +
                ", Name1='" + Name1 + '\'' +
                ", Name2='" + Name2 + '\'' +
                '}';
    }

    public Users(String Nome, String Pass, int con1, int Cont2, int codigo, String Name1, String Name2, String Sal) {
        this.Nome = Nome;
        this.Pass = Pass;
        this.Con1 = con1;
        this.Cont2 = Cont2;
        this.Codigo = codigo;
        this.Name1 = Name1;
        this.Name2 = Name2;
        this.Sal = Sal;
        this.palavra = "";
    }
    public Users() {
        this.Nome = "";
        this.Pass = "";
        this.Con1 = 0;
        this.Cont2 = 0;
        this.Codigo = 0;
        this.Name1 = "";
        this.Name2 = "";
        this.Sal = "";
        this.palavra = "Vou para as compras";
    }

    public String getPalavra() { return palavra; }

    public void setPalavra(String palavra) { this.palavra = palavra; }

    public String getName1() {
        return Name1;
    }

    public void setName1(String name1) {
        Name1 = name1;
    }

    public String getName2() {
        return Name2;
    }

    public void setName2(String name2) {
        Name2 = name2;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getPass() {
        return Pass;
    }

    public void setPass(String pass) {
        Pass = pass;
    }

    public double getCon1() {
        return Con1;
    }

    public void setCon1(double con1) {
        Con1 = con1;
    }

    public double getCont2() {
        return Cont2;
    }

    public String getSal() {
        return Sal;
    }

    public void setSal(String sal) {
        Sal = sal;
    }

    public void setCont2(double cont2) {
        Cont2 = cont2;
    }

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int codigo) {
        Codigo = codigo;
    }
}
