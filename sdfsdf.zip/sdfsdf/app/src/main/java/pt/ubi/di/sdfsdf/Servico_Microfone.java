package pt.ubi.di.sdfsdf;


import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;


import java.util.ArrayList;


public class Servico_Microfone extends Service implements RecognitionListener {

    private static final int FOREGROUND_SERVICE_TYPE_MICROPHONE = 0x00000080;
    private SpeechRecognizer speechRecognizer;
    Intent voice = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    public static final String CHANNEL_ID = "ForegroundServiceChannel";
    public String valor="";
    @Override
    public void onCreate() {
        super.onCreate();
    }

    private void sendBroadcast (boolean success){
        Intent intent = new Intent ("message"); //put the same message as in the filter you used in the activity when registering the receiver
        intent.putExtra("success", success);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @SuppressLint("WrongConstant")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String input = intent.getStringExtra("inputExtra");
        valor =  (String) intent.getStringExtra("ola");
        createNotificationChannel();
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, 0);
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Microfone em uso")
                .setContentText(input)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentIntent(pendingIntent)
                .build();
        //startForeground(1, notification);

        startForeground(1,notification,FOREGROUND_SERVICE_TYPE_MICROPHONE);
        //do heavy work on a background thread


        resetSpeechRecognizer();
        setRecogniserIntent();
        speechRecognizer.startListening(voice);

        System.out.println("dsdsds");

        //stopSelf();
        return START_NOT_STICKY;
    }

    private void resetSpeechRecognizer() {

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
        speechRecognizer.setRecognitionListener(this);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        stopSelf();
    }

    private void setRecogniserIntent() {

        voice.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getClass()
                .getPackage().getName());

        voice.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,
                "pt-PT");
        voice.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 10);
    }



    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public void onDestroy() {

        super.onDestroy();
    }

    @Override
    public void onReadyForSpeech(Bundle bundle) {

    }

    @Override
    public void onBeginningOfSpeech() {

    }

    @Override
    public void onRmsChanged(float v) {

    }

    @Override
    public void onBufferReceived(byte[] bytes) {

    }

    @Override
    public void onEndOfSpeech() {
        speechRecognizer.stopListening();
        System.out.println("acabou");
    }

    @Override
    public void onError(int i) {
        // rest voice recogniser
        //the mistake is when it i leave the app is printing ERRO in loop
        String mError="";
        switch (i) {
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                mError = " network timeout";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                mError = " network" ;

                return;
            case SpeechRecognizer.ERROR_AUDIO:
                mError = " audio";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                mError = " server";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                mError = " client";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                mError = " speech time out" ;
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                mError = " no match" ;

                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                mError = " recogniser busy" ;
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                mError = " insufficient permissions" ;
                break;

        }

        System.out.println(mError);

        resetSpeechRecognizer();
        setRecogniserIntent();
        speechRecognizer.startListening(voice);
        System.out.println("ERRO");
    }

    @Override
    public void onResults(Bundle results) {

        ArrayList<String> matches = results.getStringArrayList(speechRecognizer.RESULTS_RECOGNITION);

        System.out.println(matches);
        if(matches.size()>0){
            for(int y=0;y<matches.size();y++){
                if(matches.get(y).contains(valor)){
                    System.out.println("entrei");

                    sendBroadcast(true);
                    stopForeground(true);

                    this.stopSelf();
                }
            }
        }
/*
        System.out.println(matches);
        if (matches.contains(valor)) {
            System.out.println("entrei");

            sendBroadcast(true);
            stopForeground(true);

            this.stopSelf();
        }*/
        System.out.println("ppp");
        speechRecognizer.startListening(voice);
    }

    @Override
    public void onPartialResults(Bundle bundle) {

    }

    @Override
    public void onEvent(int i,Bundle bundle) {

    }
}