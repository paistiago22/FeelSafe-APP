package pt.ubi.di.sdfsdf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Ver_Contactos_Projeto extends AppCompatActivity {

    TextView tv1,tv2;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    //String valor;

    String c1,c2,n1,n2;


    private SQLiteDatabase sql1;
    private Dados ajudante1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_contactos_projeto);

        ajudante1 = new Dados(this);
        sql1 = ajudante1.getReadableDatabase();
        ajudante1.onCreate(sql1);

        tv1 = (TextView) findViewById(R.id.textView2);
        tv2 = (TextView) findViewById(R.id.textView33);

        //valor =  (String) getIntent().getSerializableExtra("nome");
    }

    public void ler1(){
        System.out.println("=====");
        try(Cursor c = sql1.rawQuery("SELECT * FROM INFOUSERR ", null)){
            boolean conteudo = c.moveToFirst();
            while (conteudo) {
                String s = c.getString(0);
                Double s1 = c.getDouble(1);
                String s2 = c.getString(2);
                Double s3 = c.getDouble(3);
                String s4 = c.getString(4);
                System.out.println("ola");


                //Double k = Double.parseDouble(s1);
                //System.out.println(s1);
                //System.out.println("+"+ Double.valueOf(s1).longValue());

                c1 = "+" + Double.valueOf(s1).longValue();
                c2 = "+" + Double.valueOf(s3).longValue();
                n1 = s;
                n2 = s2;

                System.out.println(c1);
                System.out.println(c2);
/*
                a.setPalavra(s4);
                a.setName2(s2);
                a.setName1(s);
                a.setCon1(s1);
                a.setCont2(s3);
                System.out.println("------------------------------------------");
                System.out.println(a);
*/

                conteudo = c.moveToNext();
                //System.out.println(conteudo);
            }
            //System.out.println(result);
        }catch(RuntimeException e){
            System.out.println(e);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ler1();

        /*
        String pp = "Users/" + valor;
        firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
        databaseReference = firebaseDatabase.getReference(pp);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            Users users = snapshot.getValue(Users.class);
                            System.out.println(Double.valueOf(users.getCon1()).longValue());
                            tv1.setText("Nome -> " + users.getName1() + "\n\n" + "Contacto -> " + "+" +Double.valueOf(users.getCon1()).longValue());
                            tv2.setText("Nome -> " + users.getName2() + "\n\n" + "Contacto -> " + "+" + Double.valueOf(users.getCont2()).longValue());
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
*/
        tv1.setText("Nome -> " + n1 + "\n\n" + "Contacto -> " + c1);
        tv2.setText("Nome -> " + n2 + "\n\n" + "Contacto -> " + c2);

    }
/*
    public void goatras(View v){
        Intent g = new Intent(this,Menu_Projeto.class);
        startActivity(g);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
*/
    public void goatras(View v){
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}