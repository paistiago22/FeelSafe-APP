package pt.ubi.di.sdfsdf;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Defenicao_Projeto extends AppCompatActivity {

    Button Mudar_Pass,Mudar_Contactos,Ver_Contactos,Atras,Mudar_Palavra;
    //String valor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_defenicao_projeto);

        Mudar_Pass = (Button) findViewById(R.id.Mudar_Pass);
        Ver_Contactos = (Button) findViewById(R.id.Ver_Contactos);
        Mudar_Contactos = (Button) findViewById(R.id.Mudar_Contactos);
        Mudar_Palavra = (Button) findViewById(R.id.Mudar_Palavra);

        Mudar_Pass.setVisibility(View.INVISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();

        //valor =  (String) getIntent().getSerializableExtra("nome");
        //System.out.println(valor);
/*
        Mudar_Pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ttv = new Intent(getBaseContext(),Mudar_Pass_Projeto.class);
                ttv.putExtra("nome",valor);
                startActivity(ttv);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
            }
        });
*/

        Mudar_Contactos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ttt = new Intent(getBaseContext(),Mudar_Contactos_Projeto.class);
                //ttt.putExtra("nome",valor);
                startActivity(ttt);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
            }
        });

        Ver_Contactos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ttt = new Intent(getBaseContext(),Ver_Contactos_Projeto.class);
                //ttt.putExtra("nome",valor);
                startActivity(ttt);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
            }
        });

        Mudar_Palavra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((ContextCompat.checkSelfPermission(Defenicao_Projeto.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)){
                    Intent tttd = new Intent(getBaseContext(),Mudar_Palavra_Projeto.class);
                    //tttd.putExtra("nome",valor);
                    startActivity(tttd);
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                }else{
                    showSettingsAlert1();
                }
            }
        });
    }

    public void goatras(View v){
        finish();
        Intent tttd = new Intent(getBaseContext(),MainActivity.class);
        startActivity(tttd);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    public void showSettingsAlert1(){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Defenicao_Projeto.this);

        // Setting Dialog Title
        alertDialog.setTitle("Permissões");

        // Setting Dialog Message
        alertDialog.setMessage("\n"+"Não tenho todas Permissões necessarias");

        // On pressing Settings button
        /*
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                mContext.startActivity(intent);
            }
        });
*/
        // on pressing cancel button
        alertDialog.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }
}