package pt.ubi.di.sdfsdf;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class AdminActivity extends AppCompatActivity {

    Button addEvent;
    //Button listEvent;
    Button adminPage;
    Button VerPessoas;
    Button notificacao;
    User curUser;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();



        setContentView(R.layout.activity_admin);

        //Receber dados do itentn
        curUser = (User)getIntent().getExtras().get("userObj");



        //Componentes
        addEvent = findViewById(R.id.addEvent);
        //listEvent = findViewById(R.id.listEvent);
        adminPage = findViewById(R.id.adminPage);
        VerPessoas = findViewById(R.id.verPessoas);
        notificacao = findViewById(R.id.Notificacao);



        //listeners
        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii = new Intent(getBaseContext(), AdminCriarEvento.class);
                startActivity(ii);
            }
        });
/*
        listEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iiI = new Intent(getBaseContext(), AdminListarEventos.class);
                startActivity(iiI);
            }
        });
*/
        adminPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), AdminPageActivity.class);
                i.putExtra("userObj", curUser);
                startActivity(i);
            }
        });
        VerPessoas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), ListarPessoas.class);
                startActivity(i);
            }
        });

        notificacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(),Admin_Notificacao.class);
                i.putExtra("userObj", curUser);
                startActivity(i);
            }
        });
    }


}