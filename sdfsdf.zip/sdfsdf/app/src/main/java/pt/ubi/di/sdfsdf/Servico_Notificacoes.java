package pt.ubi.di.sdfsdf;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.*;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.List;

public class Servico_Notificacoes extends Service implements LocationListener {

    public Context context = this;
    public Handler handler = null;
    public static Runnable runnable = null;
    List<LateLOng> valor;
    private GpsTracker gpsTracker;
    Double la = 0.0;
    Double lo = 0.0;
    Double aux_la = 0.0;
    Double aux_lo = 0.0;
    boolean f = true;
    private int count = 0;
    private NotificationManager mManager;
    private int i = 0;
    protected LocationManager locationManager;
    protected LocationListener locationListener;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void getLocation() {
        System.out.println("estou dentro");
        gpsTracker = new GpsTracker(Servico_Notificacoes.this);

        if(gpsTracker.getLatitude() != 0 && gpsTracker.getLongitude() != 0){
            la = gpsTracker.getLatitude();
            lo = gpsTracker.getLongitude();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onStart(Intent intent, int startid) {
        //Toast.makeText(this, "Service started by user.", Toast.LENGTH_LONG).show();
        valor = (ArrayList<LateLOng>) intent.getSerializableExtra("nome");
        getLocation();
        getLocation();
        NotificationChannel androidChannel = new NotificationChannel("com.sai.ANDROID",
                "ANDROID CHANNEL", NotificationManager.IMPORTANCE_DEFAULT);

        androidChannel.enableLights(true);
        androidChannel.enableVibration(true);
        androidChannel.setLightColor(Color.BLUE);
        androidChannel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

        getManager().createNotificationChannel(androidChannel);


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
    }

    private void addNotification() {
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(getBaseContext(), "com.sai.ANDROID")
                .setSmallIcon(R.drawable.sereia)
                .setPriority(Notification.PRIORITY_MAX)
                .setContentTitle("Perigo")
                .setColor(Color.RED)
                .setVibrate(new long[] { 1000, 1000, 1000, 1000, 1000 })
                .setContentText("Encontra-se em zona de perigo")
                .setContentInfo("Info")
                .setStyle(new NotificationCompat.DecoratedCustomViewStyle());

        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        notificationBuilder.setSound(alarmSound);

        NotificationManager notificationManager = (NotificationManager) getBaseContext().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(i, notificationBuilder.build());
        i++;
    }

    private NotificationManager getManager() {
        if (mManager == null) {
            mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return mManager;
    }

    @Override
    public void onCreate() {
        Toast.makeText(this, "O servico foi inicializado", Toast.LENGTH_LONG).show();
        //getLocation();
        //getLocation();
        handler = new Handler();
        runnable = new Runnable() {
            public void run() {

                getLocation();

                System.out.println(la);
                System.out.println(lo);

                System.out.println("Contador : " + count);

                for(int i=0;i<valor.size();i++){
                    if(aux_la == 0 || distance(aux_la,aux_lo,la,lo) > 0.2){
                        //Toast.makeText(context, "Tenho loc", Toast.LENGTH_LONG).show();
                        if(distance(la,lo,valor.get(i).getLatitude(), valor.get(i).getLongitude()) < 0.2 ){
                            //Toast.makeText(context, lo.toString(), Toast.LENGTH_LONG).show();
                            System.out.println(valor.get(i));
                            addNotification();
                            aux_la = valor.get(i).getLatitude();
                            aux_lo = valor.get(i).getLongitude();
                            break;
                        }
                    }
                }
                count++;
                handler.postDelayed(runnable, 5000);
            }
        };

        handler.postDelayed(runnable, 5000);
    }

    @Override
    public void onDestroy() {
        /* IF YOU WANT THIS SERVICE KILLED WITH THE APP THEN UNCOMMENT THE FOLLOWING LINE */
        handler.removeCallbacks(runnable);
        Toast.makeText(this, "O servico foi desligado", Toast.LENGTH_LONG).show();
    }


    private double distance(double lat1, double lng1, double lat2, double lng2) {

        double earthRadius = 6371;

        double dLat = Math.toRadians(lat2-lat1);
        double dLng = Math.toRadians(lng2-lng1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        double dist = earthRadius * c;

        return dist; // output distance, in KM
    }



    @Override
    public void onLocationChanged(Location location) {

        lo = location.getLongitude();
        la = location.getLatitude();
    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.d("Latitude","disable");
    }

    @Override
    public void onProviderEnabled(String provider) {
        Log.d("Latitude","enable");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.d("Latitude","status");
    }
}