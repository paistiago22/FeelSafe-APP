package pt.ubi.di.sdfsdf;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hbb20.CountryCodePicker;
import com.squareup.picasso.Picasso;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Mudar_Contactos_Projeto extends AppCompatActivity {

    EditText tv1,tv2,tv3,tv4;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    Button butao;
    //String valor;
    private CountryCodePicker r1;
    private CountryCodePicker r2;

    private SQLiteDatabase sql1;
    private Dados ajudante1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mudar_contactos_projeto);

        tv1 = (EditText) findViewById(R.id.edittext);
        tv2 = (EditText) findViewById(R.id.edittext2);
        tv3 = (EditText) findViewById(R.id.edittext3);
        tv4 = (EditText) findViewById(R.id.edittext4);
        r1 = findViewById(R.id.countryCode_picker11);
        r2 = findViewById(R.id.countryCode_picker22);

        butao = (Button) findViewById(R.id.button44);

        //valor =  (String) getIntent().getSerializableExtra("nome");

        ajudante1 = new Dados(this);
        sql1 = ajudante1.getReadableDatabase();
        ajudante1.onCreate(sql1);

    }

    @Override
    protected void onResume() {
        super.onResume();

        System.out.println("ola");

        butao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int t22;
                int t33;


                if(tv2.getText().toString().equals("")){
                    t22 = 0;
                }else{
                    t22 = Integer.parseInt(tv2.getText().toString());
                }

                if(tv4.getText().toString().equals("")){
                    t33 = 0;
                }else{
                    t33 = Integer.parseInt(tv4.getText().toString());
                }


                //verificar campos em branco
                if(tv1.getText().toString().equals("") || tv3.equals("") || t33 ==0 || t22 ==0 ){
                    System.out.println("Insira as credenciais! ou preencha devidamente os contactos");

                    GradientDrawable gdf = new GradientDrawable();
                    gdf.setColor(Color.parseColor("#00ffffff"));
                    gdf.setStroke(2,Color.WHITE);
                    tv1.setBackground(gdf);
                    tv3.setBackground(gdf);
                    tv2.setBackground(gdf);
                    tv4.setBackground(gdf);

                    if (tv1.getText().toString().equals("")){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        tv1.setBackground(gd);
                    }
                    if (tv3.getText().toString().equals("") ){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        tv3.setBackground(gd);
                    }
                    if (t22 == 0 ){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        tv2.setBackground(gd);
                    }
                    if (t33 == 0 ){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        tv4.setBackground(gd);
                    }

                } else {

                    /*
                    //verificar credenciais na base de dados
                    String pp = "Users/" + valor;
                    firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
                    databaseReference = firebaseDatabase.getReference(pp);

                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        boolean verify = true;
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists()){
                                System.out.println("EXISTS");
                                databaseReference.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        System.out.println("EXISTS");
                                        Users users = snapshot.getValue(Users.class);


                                        String code = r1.getSelectedCountryCode();
                                        System.out.println(code);

                                        String code2 = r2.getSelectedCountryCode();
                                        System.out.println(code2);

                                        String h1 = code + tv2.getText().toString();
                                        System.out.println(h1);

                                        String h2 = code2 + tv4.getText().toString();
                                        System.out.println(h2);

                                        users.setName1(tv1.getText().toString());
                                        users.setName2(tv3.getText().toString());
                                        users.setCon1(Double.parseDouble(h1));
                                        users.setCont2(Double.parseDouble(h2));
                                        addDatatoFirebase(users);
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                    }
                                });
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                    */


                    System.out.println("AQUI12");

                    String code = r1.getSelectedCountryCode();
                    System.out.println(code);

                    String code2 = r2.getSelectedCountryCode();
                    System.out.println(code2);

                    String h1 = code + tv2.getText().toString();
                    System.out.println(h1);

                    String h2 = code2 + tv4.getText().toString();
                    System.out.println(h2);

                    ContentValues contentValues22=new ContentValues();
                    contentValues22.put(Dados.COLUMN1,tv1.getText().toString());
                    contentValues22.put(Dados.COLUMN2,Double.parseDouble(h1));
                    contentValues22.put(Dados.COLUMN3,tv3.getText().toString());
                    contentValues22.put(Dados.COLUMN4,Double.parseDouble(h2));

                    sql1.update(Dados.TABLE_NAME1,contentValues22,"ID=?", new String[]{String.valueOf(1)});

                    Toast.makeText(getApplicationContext(), "Sucesso", Toast.LENGTH_SHORT).show();
                    Intent tttt = new Intent(getBaseContext(),Defenicao_Projeto.class);
                    startActivity(tttt);



                }
            }
        });
    }

    private void addDatatoFirebase(Users a) {

        firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");

        String p = "Users/" + a.getNome();
        databaseReference = firebaseDatabase.getReference(p);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                databaseReference.setValue(a);
                Toast.makeText(getApplicationContext(), "Sucesso", Toast.LENGTH_SHORT).show();
                Intent tttt = new Intent(getBaseContext(),Defenicao_Projeto.class);
                startActivity(tttt);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
/*
    public void goatras(View v){
        Intent g = new Intent(this,Menu_Projeto.class);
        startActivity(g);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
*/
    public void goatras(View v){
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

}