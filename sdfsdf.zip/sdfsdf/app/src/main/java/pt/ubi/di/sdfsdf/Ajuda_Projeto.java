package pt.ubi.di.sdfsdf;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.speech.SpeechRecognizer;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

//public class Ajuda_Projeto extends AppCompatActivity implements RecognitionListener {

    public class Ajuda_Projeto extends AppCompatActivity {
    //Initialize variable
    private Button btLocation;
    TextView textView1, textView5;
    FusedLocationProviderClient fusedLocationProviderClient;
    private Handler mHandler = new Handler();
    boolean p = false;
    boolean jj = false;
    boolean g = true;
    String nome1,nome2,palavra;
    Long con1,con2;
    String con11,con22;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    CountDownTimer mcount;
    boolean tudo_bem = false;
    private GpsTracker gpsTracker;
    private TextView tvLatitude,tvLongitude,tv;
    private final int REQUEST_READ_PHONE_STATE=1;
    boolean b = true;
    private boolean pl = false;

    private static final String LOG_TAG = "AudioRecordTest";
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private static String fileName = null;

    //private RecordButton recordButton = null;
    private MediaRecorder recorder ;

    //private PlayButton   playButton = null;
    private MediaPlayer player = null;
    private boolean permissionToRecordAccepted = false;
    private String [] permissions = {Manifest.permission.RECORD_AUDIO};

    private boolean h = false;

    private static final int PERMISSIONS_REQUEST_RECORD_AUDIO = 1;
    private TextView returnedText;
    private TextView returnedError;
    private ProgressBar progressBar;
    private SpeechRecognizer speech = null;
    private Intent recognizerIntent;
    private String LOG_TAG1 = "VoiceRecognitionActivity";
    public static final String CHANNEL_ID = "ForegroundServicdeChannel";
    public NotificationManagerCompat notificationManager1;
    Intent serviceIntent;
/*
    private void resetSpeechRecognizer() {

        if(speech != null)
            speech.destroy();
        speech = SpeechRecognizer.createSpeechRecognizer(this);
        Log.i(LOG_TAG1, "isRecognitionAvailable: " + SpeechRecognizer.isRecognitionAvailable(this));
        if(SpeechRecognizer.isRecognitionAvailable(this))
            speech.setRecognitionListener(this);
        else
            finish();
    }

    private void setRecogniserIntent() {

        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,
                "pt-PT");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
    }
*/
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajuda_projeto);



        btLocation = (Button) findViewById(R.id.bt12);
        textView5 = findViewById(R.id.te);
        textView1 = findViewById(R.id.textView);
        tvLatitude = (TextView)findViewById(R.id.textView2);
        tvLongitude = (TextView)findViewById(R.id.textView3);

        textView5.setVisibility(View.INVISIBLE);
        tvLatitude.setVisibility(View.INVISIBLE);
        tvLongitude.setVisibility(View.INVISIBLE);

        returnedText = findViewById(R.id.textView12);
        returnedError = findViewById(R.id.errorView1w);
        progressBar =  findViewById(R.id.progressBar11);
        progressBar.setVisibility(View.INVISIBLE);
        returnedError.setVisibility(View.INVISIBLE);

        LocalBroadcastManager.getInstance(this).registerReceiver(bReceiver, new IntentFilter("message"));

        btLocation.setVisibility(View.INVISIBLE);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd__HH_mm_ss", Locale.getDefault());
        String currentDateandTime = sdf.format(new Date());

        fileName = getExternalCacheDir().getAbsolutePath();
        fileName +=  "/" + currentDateandTime +"RecordedAudio.3gp";

        gpsTracker = new GpsTracker(Ajuda_Projeto.this);

        ActivityCompat.requestPermissions(this, permissions, REQUEST_RECORD_AUDIO_PERMISSION);

        palavra =  (String) getIntent().getSerializableExtra("palavra");

        System.out.println(palavra);

        serviceIntent = new Intent(this, Servico_Microfone.class);
        serviceIntent.putExtra("inputExtra", "Microfone em uso para captar a frase secreta");
        serviceIntent.putExtra("ola",palavra);
        ContextCompat.startForegroundService(this, serviceIntent);




    }


        @Override
        protected void onDestroy() {
            super.onDestroy();

        }

        private BroadcastReceiver bReceiver = new BroadcastReceiver(){
            @Override
            public void onReceive(Context context, Intent intent) {
                if(!h){
                    System.out.println("principla");
                    //Intent serviceIntent = new Intent(getApplicationContext(), MyService.class);
                    stopService(serviceIntent);
                    h = true;

                    if (ContextCompat.checkSelfPermission(Ajuda_Projeto.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                        ActivityCompat.requestPermissions(Ajuda_Projeto.this,new String[]{ Manifest.permission.ACCESS_FINE_LOCATION },100);
                    }

                    else{
                        //stopService(new Intent(getBaseContext(), MyService.class));
                        if(jj == false){
                            getLocation();
                            jj = true;
                            b = false;
                        }

                        if(p == false){
                            p = true;
                            getLocation();
                            try {
                                onRecord(true);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            mToastRunnable.run();
                            btLocation.setText("PARAR");
                            System.out.println("polkiuanfuiansfui");
                            btLocation.setVisibility(View.VISIBLE);
                        }
                        else{
                            p = false;
                            mHandler.removeCallbacks(mToastRunnable);
                            mcount.cancel();
                            g = false;
                            System.out.println("CANCEL");
                            tudo_bem = true;
                            //ACABOU (MANDAR SMS -> TUDO BEM -> IR PARA OUTRA ATIVIDADE)
                            try {
                                onRecord(false);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(),"Ja esta tudo bem! Obrigado");
                            sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(),"Ja esta tudo bem! Obrigado");
                            btLocation.setVisibility(View.INVISIBLE);
                            Intent ttv = new Intent(getBaseContext(),MainActivity.class);
                            startActivity(ttv);
                            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                            finish();

                        }
                    }
                }
            }
    };

    public void goatras(View v){
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }


        @Override
    protected void onResume() {
        super.onResume();
/*
            Intent intentAction = new Intent(getBaseContext(),Accept.class);

            //This is optional if you have more than one buttons and want to differentiate between two
            intentAction.putExtra("action","actionName");

            PendingIntent pIntentlogin = PendingIntent.getBroadcast(getBaseContext(),1,intentAction,PendingIntent.FLAG_UPDATE_CURRENT);
            NotificationCompat.Builder drivingNotifBldr = (NotificationCompat.Builder) new NotificationCompat.Builder(getBaseContext())
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("NoTextZone")
                    .setContentText("Driving mode it ON!")
                    //Using this action button I would like to call logTest
                    .addAction(R.drawable.ic_launcher_foreground, "Turn OFF driving mode", pIntentlogin)
                    .setOngoing(true);


            NotificationManager notificationManager = (NotificationManager) getBaseContext().getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(1, drivingNotifBldr.build());

*/

            //AudioManager amanager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
        //amanager.setStreamMute(AudioManager.STREAM_NOTIFICATION, true);
/*
        resetSpeechRecognizer();
        setRecogniserIntent();
        speech.startListening(recognizerIntent);
*/
        nome1 =  (String) getIntent().getSerializableExtra("nome1");
        nome2 =  (String) getIntent().getSerializableExtra("nome2");
        con1 =  (Long) getIntent().getSerializableExtra("con1");
        con2 =  (Long) getIntent().getSerializableExtra("con2");

        System.out.println(con1);
        System.out.println("asdasd");

        System.out.println("+"+ Double.valueOf(con1).longValue());
        System.out.println("+"+ Double.valueOf(con2).longValue());



        // start speech recogniser
       // resetSpeechRecognizer();

        // start progress bar
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);

        // check for permission
        int permissionCheck1 = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.RECORD_AUDIO);

        if (permissionCheck1 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSIONS_REQUEST_RECORD_AUDIO);
            return;
        }


        //setRecogniserIntent();
        //speech.startListening(recognizerIntent);


        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        if (ContextCompat.checkSelfPermission(Ajuda_Projeto.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(Ajuda_Projeto.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},100);
        }else{
            //getLocation();



        }

        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE);

        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, REQUEST_READ_PHONE_STATE);
        }
/*
        gpsTracker1 = new GpsTracker(Ajuda_Projeto.this);
        if(!gpsTracker1.canGetLocation()){
            gpsTracker1.showSettingsAlert();
        }
*/
        btLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Check permission
                stopService(serviceIntent);
                //ContextCompat.stopForegroundService(getApplicationContext(), serviceIntent);
                if ((ContextCompat.checkSelfPermission(Ajuda_Projeto.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)){
                    ActivityCompat.requestPermissions(Ajuda_Projeto.this,new String[]{ Manifest.permission.ACCESS_FINE_LOCATION },42);
                }
                else{
                    //stopService(new Intent(getBaseContext(), MyService.class));
                    System.out.println("NAOOOOO");
                    if(jj == false){
                        getLocation();
                        jj = true;
                        b = false;
                    }

                    if(p == false){
                        p = true;
                        getLocation();
                        try {
                            //if ((ContextCompat.checkSelfPermission(Ajuda_Projeto.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)){
                                onRecord(true); //GRAVAR AUDIO
                            //}

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        mToastRunnable.run();
                        btLocation.setText("PARAR");
                        btLocation.setVisibility(View.VISIBLE);
                    }
                    else{
                        p = false;
                        mHandler.removeCallbacks(mToastRunnable);
                        mcount.cancel();
                        g = false;
                        System.out.println("CANCEL");
                        tudo_bem = true;
                        //ACABOU (MANDAR SMS -> TUDO BEM -> IR PARA OUTRA ATIVIDADE)
                        try {
                            //if ((ContextCompat.checkSelfPermission(Ajuda_Projeto.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)){
                                onRecord(false); //GRAVAR AUDIO
                            //}
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(),"Ja esta tudo bem! Obrigado");
                        sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(),"Ja esta tudo bem! Obrigado");
                        btLocation.setVisibility(View.INVISIBLE);
                        finish();

                    }
                }

            }
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    public void getLocation(){
        //gpsTracker = new GpsTracker(Ajuda_Projeto.this);
        if(gpsTracker.canGetLocation()){
            double latitude = gpsTracker.getLatitude();
            double longitude = gpsTracker.getLongitude();
            System.out.println(latitude);
            System.out.println(longitude);
            try{
                getAddress(latitude,longitude,b);
                //tvLatitude.setVisibility(View.VISIBLE);
                //tvLongitude.setVisibility(View.VISIBLE);
                tvLatitude.setText(String.valueOf(latitude));
                tvLongitude.setText(String.valueOf(longitude));
            }catch(Exception e){
                System.out.println("Nao consegue obter a morada");
                tvLatitude.setText(String.valueOf(latitude));
                tvLongitude.setText(String.valueOf(longitude));

                if(!pl){
                    sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(),"Ola , estou em perigo" );
                    //sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(), textView5.getText().toString());
                    sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(),"Ola , estou em perigo" );
                    //sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(), textView5.getText().toString());
                    pl = true;
                }

                e.printStackTrace();
            }
        }else{

            if(!pl){
                sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(),"Ola , estou em perigo" );
                //sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(), textView5.getText().toString());
                sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(),"Ola , estou em perigo" );
                //sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(), textView5.getText().toString());
                pl = true;
            }

        }
    }


    public void sendSmsMsgFnc(String mblNumVar, String smsMsgVar)
    {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
        {
            try
            {
                SmsManager smsMgrVar = SmsManager.getDefault();
                smsMgrVar.sendTextMessage(mblNumVar, null, smsMsgVar, null, null);

            }
            catch (Exception ErrVar)
            {
                Toast.makeText(getApplicationContext(),ErrVar.getMessage().toString(),
                        Toast.LENGTH_LONG).show();
                ErrVar.printStackTrace();
            }
        }
        else
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 10);
            }
        }
    }


    public void getAddress(double lat, double lng,boolean b) {
        Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());

        try {

            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            System.out.println(addresses);
            Address obj = addresses.get(0);
            String add = obj.getAddressLine(0);
            //String city = addresses.get(0).getLocality();
            textView5.setText(add);
            System.out.println(b+"ppo");
            if(b){
                String hh = Hash_Help.getSalt11();
                LateLOng o = new LateLOng(lat,lng);
                addDatatoFirebase(hh,o);
                System.out.println("VIMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
                b = false;
                System.out.println("1 vez");
                sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(),"Ola , estou em perigo...minha localizacao: " );
                sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(), textView5.getText().toString());
                sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(),"Ola , estou em perigo...minha localizacao: " );
                sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(), textView5.getText().toString());

            }else{
                System.out.println("2 vez");
                sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(), textView5.getText().toString());
                sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(), textView5.getText().toString());
            }
            b = false;

        } catch (IOException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void addDatatoFirebase(String j, LateLOng i) {
        //verificar credenciais na base de dados
        firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
        String p = "Local/" + j;
        databaseReference = firebaseDatabase.getReference(p);
        final boolean[] r = new boolean[1];
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            boolean verify = true;
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    //Toast.makeText(Ajuda_Projeto.this, "Ja existe o UserName", Toast.LENGTH_SHORT).show();
                    verify = false;
                    r[0] = verify;
                } else {
                    //Toast.makeText(Ajuda_Projeto.this, "Sucesso", Toast.LENGTH_SHORT).show();
                    databaseReference.setValue(i);
                    r[0] = verify;
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
/*
        public void sendSMS()
        {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
            {
                try
                {
                if(tudo_bem==true){
                    SmsManager smsMgrVar = SmsManager.getDefault();
                    smsMgrVar.sendTextMessage("+351915409949", null, "Ja esta tudo bem! Obrigado", null, null);
                    Toast.makeText(getApplicationContext(), "Message Sent", Toast.LENGTH_LONG).show();
                }
                else{
                    SmsManager smsMgrVar = SmsManager.getDefault();
                    String h = textView5.getText().toString();
                    smsMgrVar.sendTextMessage("+351915409949", null, h, null, null);
                    Toast.makeText(getApplicationContext(), "Message Sent", Toast.LENGTH_LONG).show();
                }


                    String jo = "+351915409949";
                    if(tudo_bem==true){
                        SmsManager smsMgrVar = SmsManager.getDefault();
                        smsMgrVar.sendTextMessage(con11, null, "Ja esta tudo bem! Obrigado", null, null);

                        SmsManager smsMgrVar1 = SmsManager.getDefault();
                        smsMgrVar1.sendTextMessage(con22, null, "Ja esta tudo bem! Obrigado", null, null);
                        Toast.makeText(getApplicationContext(), "Message Sent", Toast.LENGTH_LONG).show();
                    }
                    else {
                        SmsManager smsMgrVar = SmsManager.getDefault();
                        String h = nome1 +"Estou em perigo...Minha localizacao : "+textView5.getText().toString();
                        smsMgrVar.sendTextMessage(jo, null, h, null, null);

                        SmsManager smsMgrVar1 = SmsManager.getDefault();
                        String h1 = nome2 +"Estou em perigo...Minha localizacao : "+textView5.getText().toString();
                        smsMgrVar1.sendTextMessage("+"+ Double.valueOf(con2).longValue(), null, h1, null, null);
                        Toast.makeText(getApplicationContext(), "Message Sent", Toast.LENGTH_LONG).show();
                    }

                }
                catch (Exception ErrVar)
                {
                    System.out.println("ola3");
                    Toast.makeText(getApplicationContext(),ErrVar.getMessage().toString(),
                            Toast.LENGTH_LONG).show();
                    ErrVar.printStackTrace();
                }
            }
            else
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                {
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 10);
                }
            }
        }

*/

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_READ_PHONE_STATE:
                if ((grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {

                }
                break;
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecordAccepted  = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
            default:
                break;
        }

        if (requestCode == PERMISSIONS_REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                speech.startListening(recognizerIntent);
            } else {
                Toast.makeText(Ajuda_Projeto.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                finish();
            }
        }

        if (!permissionToRecordAccepted ) finish();
    }


    private Runnable mToastRunnable = new Runnable() {
        @Override
        public void run() {
            long duration = TimeUnit.MINUTES.toMillis(1);
            if(g == true){
                mcount = new CountDownTimer(duration, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        String sdur = String.format(Locale.ENGLISH, "%02d : %02d",
                                TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished),
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
                                        TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)
                                ));
                        textView1.setText(sdur);
                    }
                    @Override
                    public void onFinish() {
                        textView5.setText("");
                        getLocation();
                        b = false;
                    }
                }.start();
            }
            mHandler.postDelayed(this, 1000*60);
        }
    };

    private void onRecord(boolean start) throws IOException {
        if (start) {
            startRecording();
        } else {
            stopRecording();
        }
    }


    private void startRecording() {

        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setOutputFile(fileName);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            recorder.prepare();
        } catch (IOException e) {
            Log.e(LOG_TAG1, "prepare() failed");
        }

        recorder.start();
    }

    private void stopRecording() throws IOException {
        recorder.stop();
        recorder.release();
        recorder = null;
    }
/*
    @Override
    protected void onPause() {
        Log.i(LOG_TAG1, "pause");
        super.onPause();
        speech.stopListening();
    }

    @Override
    protected void onStop() {
        Log.i(LOG_TAG1, "stop");
        super.onStop();
        if (speech != null) {
            speech.destroy();
        }
    }


    @Override
    public void onBeginningOfSpeech() {
        Log.i(LOG_TAG1, "onBeginningOfSpeech");
        progressBar.setIndeterminate(false);
        progressBar.setMax(10);
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
        Log.i(LOG_TAG1, "onBufferReceived: " + buffer);
    }

    @Override
    public void onEndOfSpeech() {
        Log.i(LOG_TAG1, "onEndOfSpeech");
        progressBar.setIndeterminate(true);
        speech.stopListening();
    }

    @Override
    public void onResults(Bundle results) {
        Log.i(LOG_TAG1, "onResults");
        ArrayList<String> matches = results
                .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String text = "";
        for (String result : matches)
            text += result;

        returnedText.setText(text);

        if(text.equalsIgnoreCase(palavra)){
            if (ContextCompat.checkSelfPermission(Ajuda_Projeto.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(Ajuda_Projeto.this,new String[]{ Manifest.permission.ACCESS_FINE_LOCATION },100);
            }
            else if(!(gpsTracker.canGetLocation())){
                gpsTracker.showSettingsAlert();System.out.println("aquiiiiii222222222");
            }
            else{
                //stopService(new Intent(getBaseContext(), MyService.class));
                if(jj == false){
                    getLocation();
                    jj = true;
                    b = false;
                }

                if(p == false){
                    p = true;
                    getLocation();
                    try {
                        onRecord(true);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    mToastRunnable.run();
                    btLocation.setText("PARAR");
                }
                else{
                    p = false;
                    mHandler.removeCallbacks(mToastRunnable);
                    mcount.cancel();
                    g = false;
                    System.out.println("CANCEL");
                    tudo_bem = true;
                    //ACABOU (MANDAR SMS -> TUDO BEM -> IR PARA OUTRA ATIVIDADE)
                    try {
                        onRecord(false);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    sendSmsMsgFnc("+"+ Double.valueOf(con1).longValue(),"Ja esta tudo bem! Obrigado");
                    sendSmsMsgFnc("+"+ Double.valueOf(con2).longValue(),"Ja esta tudo bem! Obrigado");
                        Intent ttv = new Intent(getBaseContext(),Menu_Projeto.class);
                        startActivity(ttv);
                        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                    finish();

                }
            }
        }

        speech.startListening(recognizerIntent);
    }

    @Override
    public void onError(int errorCode) {
        String errorMessage = getErrorText(errorCode);
        Log.i(LOG_TAG1, "FAILED " + errorMessage);
        returnedError.setText(errorMessage);

        // rest voice recogniser
        resetSpeechRecognizer();
        speech.startListening(recognizerIntent);
    }

    @Override
    public void onEvent(int arg0, Bundle arg1) {
        Log.i(LOG_TAG1, "onEvent");
    }

    @Override
    public void onPartialResults(Bundle arg0) {
        Log.i(LOG_TAG1, "onPartialResults");
    }

    @Override
    public void onReadyForSpeech(Bundle arg0) {
        Log.i(LOG_TAG1, "onReadyForSpeech");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
        //Log.i(LOG_TAG1, "onRmsChanged: " + rmsdB);
        progressBar.setProgress((int) rmsdB);
    }

    public String getErrorText(int errorCode) {
        String message;
        switch (errorCode) {
            case SpeechRecognizer.ERROR_AUDIO:
                message = "Audio recording error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                message = "Client side error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                message = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "RecognitionService busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                message = "error from server";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "No speech input";
                break;
            default:
                message = "Didn't understand, please try again.";
                break;
        }
        return message;
    }*/
}