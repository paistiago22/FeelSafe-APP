package pt.ubi.di.sdfsdf;

import java.io.Serializable;



public class LateLOng implements Serializable {
    private Double Latitude;
    private Double Longitude;


    public LateLOng() {
        this.Latitude = 0.0;
        this.Longitude = 0.0;

    }

    public LateLOng(Double Latitude, Double Longitude) {
        this.Latitude = Latitude;
        this.Longitude = Longitude;

    }


    public Double getLatitude() {
        return Latitude;
    }
    public Double getLongitude() {
        return Longitude;
    }

    public void setLatitude(Double Latitude) {
        this.Latitude = Latitude;
    }
    public void setLongitude(Double Longitude) {
        this.Longitude = Longitude;
    }


    @Override
    public Object clone(){
        LateLOng copia = new LateLOng (this.Latitude ,this.Longitude);
        return copia;
    }

    @Override
    public String toString() {
        return
                "la='" + Latitude + '\'' +
                "++ lo='" + Longitude;
    }
}


