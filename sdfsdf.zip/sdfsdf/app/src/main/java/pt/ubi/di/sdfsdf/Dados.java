package pt.ubi.di.sdfsdf;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Dados extends SQLiteOpenHelper{


    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "DataBase";


    protected static final String TABLE_NAME1 = "INFOUSERR";
    protected static final String COLUMN1 = "Nome1";
    protected static final String COLUMN2 = "Numero1";
    protected static final String COLUMN3 = "Nome2";
    protected static final String COLUMN4 = "Numero2";
    protected static final String COLUMN5 = "Palavra";
    protected static final String COLUMN6 = "ID";



    private static final String JOGOS_TABLE_CREATE =
            "CREATE TABLE IF NOT EXISTS " + TABLE_NAME1 + "(" + COLUMN1 + " VARCHAR(90), " + COLUMN2 + " REAL, " + COLUMN3 + " VARCHAR(90)," + COLUMN4 + " REAL," + COLUMN5 + " VARCHAR(90)," + COLUMN6 + " INTEGER)";


    private static final String JOGOS_TABLE_DROP = "DROP TABLE " + TABLE_NAME1 + ";";

    private static final String JOGOS_AUX_TABLE_DROP = "DROP TABLE JogosAux;";

    private static final String JOGOS_TABLE_TEMP = "CREATE TEMP TABLE JogosAux AS SELECT * FROM " + TABLE_NAME1 + ";";

    private static final String JOGOS_TABLE_INSERT = "INSERT INTO " + TABLE_NAME1 + "(" + COLUMN1 + ", " + COLUMN2 + ") SELECT * FROM JogosAux;";

    public Dados(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(JOGOS_TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL(JOGOS_TABLE_TEMP);
        db.execSQL(JOGOS_TABLE_DROP);
        db.execSQL(JOGOS_TABLE_CREATE);
        db.execSQL(JOGOS_TABLE_INSERT);
        db.execSQL(JOGOS_AUX_TABLE_DROP);
    }

}


