package pt.ubi.di.sdfsdf;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.TileOverlay;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.maps.android.heatmaps.Gradient;
import com.google.maps.android.heatmaps.HeatmapTileProvider;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;


public class mapa extends AppCompatActivity {
    private SQLiteDatabase sql;
    private AjudaBaseDados ajudante;
    List<LatLng> result = new ArrayList<>();
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa);
    }

    @Override
    protected void onResume() {
        super.onResume();

        ajudante = new AjudaBaseDados(this);
        sql = ajudante.getReadableDatabase();

        ajudante.onCreate(sql);

        ler();


    }

    public void ler(){
        try(Cursor c = sql.rawQuery("SELECT * FROM INFO ", null)){
            boolean conteudo = c.moveToFirst();
            System.out.println(conteudo);
            while (conteudo) {
                double s = c.getDouble(0);
                double s1 = c.getDouble(1);
                result.add(new LatLng(s, s1));
                conteudo = c.moveToNext();
                System.out.println(conteudo);
            }
            System.out.println("sfdddddddddddddddddddddddd");
            System.out.println(result);
        }catch(RuntimeException e){
            System.out.println("deu erro");
        }
    }
}
