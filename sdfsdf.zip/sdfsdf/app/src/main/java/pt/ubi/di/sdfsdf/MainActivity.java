package pt.ubi.di.sdfsdf;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button Button_def,Button_Help,Button_Mapa,Button_sair,Button;
    Switch aSwitch;
    //String valor;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private SQLiteDatabase sql;
    private AjudaBaseDados ajudante;

    private SQLiteDatabase sql1;
    private Dados ajudante1;

    String nome1,nome2,palavra;
    long contacto1;
    long contacto2;


    private GpsTracker gpsTracker;
    private GpsTracker gpsTracker1;
    private GpsTracker gpsTracker2;
    private GpsTracker gpsTracker3;
    List<LatLng> result = new ArrayList<LatLng>();
    List<LateLOng> result1 = new ArrayList<LateLOng>();
    double latitude=0;
    double longitude=0;
    Users a = new Users();



    public void showSettingsAlert1(){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);

        // Setting Dialog Title
        alertDialog.setTitle("Permissões");

        // Setting Dialog Message
        alertDialog.setMessage("\n"+"Não tenho todas Permissões necessarias");

        // On pressing Settings button
        /*
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                mContext.startActivity(intent);
            }
        });
*/
        // on pressing cancel button
        alertDialog.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    public void showSettingsAlert2(){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);

        // Setting Dialog Title
        alertDialog.setTitle("Localizacao");

        // Setting Dialog Message
        alertDialog.setMessage("\n"+"Não tenho acesso");

        // On pressing Settings button
        /*
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                mContext.startActivity(intent);
            }
        });
*/
        // on pressing cancel button
        alertDialog.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }



    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ajudante = new AjudaBaseDados(this);
        sql = ajudante.getReadableDatabase();
        ajudante.onCreate(sql);
        gpsTracker1 = new GpsTracker(MainActivity.this);

        Button_def = (Button) findViewById(R.id.button3);
        Button_Help = (Button) findViewById(R.id.button);
        Button_Mapa = (Button) findViewById(R.id.button2);
        Button_sair = (Button) findViewById(R.id.button55);
        //Button = (Button) findViewById(R.id.button22);
        aSwitch = (Switch) findViewById(R.id.switch1);

        tt();

        ler();
        ler1();

        AudioManager amanager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        amanager.setStreamMute(AudioManager.STREAM_NOTIFICATION, true);
/*
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
        {
        }
        else
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 10);
            }
        }
*/


        int permissionsCode = 42;
        String[] permissions = {Manifest.permission.SEND_SMS, Manifest.permission.ACCESS_NETWORK_STATE,Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_PHONE_STATE,Manifest.permission.INTERNET,Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.WRITE_EXTERNAL_STORAGE};

        if (!hasPermissions(this, permissions)) {
            ActivityCompat.requestPermissions(this, permissions, permissionsCode);
        }


/*
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            //ActivityCompat.requestPermissions(MainActivity.this,new String[]{ Manifest.permission.ACCESS_FINE_LOCATION },100);
            System.out.println("permissao");
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
        }


        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{ Manifest.permission.INTERNET },101);
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{ Manifest.permission.ACCESS_NETWORK_STATE },102);
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{ Manifest.permission.ACCESS_COARSE_LOCATION },103);
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{ Manifest.permission.READ_PHONE_STATE },104);
        }

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{ Manifest.permission.RECORD_AUDIO },105);
        }
*/




        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        {
        }
        else
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 105);
            }
        }



        if(!gpsTracker1.canGetLocation()){
            showSettingsAlert2();
        }


    }


    @Override
    protected void onResume() {
        super.onResume();

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if((ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)){

                    gpsTracker3 = new GpsTracker(MainActivity.this);
                    if(gpsTracker3.canGetLocation()){
                        if(isChecked){
                            Intent ttttq = new Intent(getBaseContext(), Servico_Notificacoes.class);
                            getLocation();
                            ttttq.putExtra("nome", (ArrayList<LateLOng>) result1);
                            startService(ttttq);
                        }else{
                            System.out.println("xau");
                            stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));
                        }
                    }
                    else{
                        aSwitch.setChecked(false);
                        showSettingsAlert2();
                    }
                }else{
                    aSwitch.setChecked(false);
                    showSettingsAlert1();
                }
            }
        });

        Button_def.setOnClickListener(v -> {
            Intent tt = new Intent(getBaseContext(),Defenicao_Projeto.class);
            //tt.putExtra("nome",valor);
            startActivity(tt);
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
        });

        Button_Mapa.setOnClickListener(v -> {

            gpsTracker2 = new GpsTracker(MainActivity.this);
            //if(gpsTracker2.canGetLocation()){

            //Button.setText("COMECAR");
            stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));
            aSwitch.setChecked(false);
            if(gpsTracker2.canGetLocation()){
                getLocation();
            }


            System.out.println("Aqui");

            System.out.println(result.toString());

            Intent tttt = new Intent(getBaseContext(),MapsActivity6.class);
            tttt.putExtra("nome", (ArrayList<LatLng>) result);
            tttt.putExtra("la",latitude);
            tttt.putExtra("lo",longitude);
            startActivity(tttt);
            //}else{
            //  showSettingsAlert2();
            //}

        });



        Button_sair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Button.setText("COMECAR");
                stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));

                goatras();
            }

        });


        Button_Help.setOnClickListener(v -> {
            //verificar credenciais na base de dados

            if((ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)){

                gpsTracker1 = new GpsTracker(MainActivity.this);

                    /*
                    String pp = "Users/" + valor;
                    firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
                    databaseReference = firebaseDatabase.getReference(pp);
                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        boolean verify = true;
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists()){
                                System.out.println("EXISTS");
                                databaseReference.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        System.out.println("EXISTS");
                                        Users users = snapshot.getValue(Users.class);
                                        Users d = users;

                                        //Button.setText("COMECAR");
                                        stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));
                                        aSwitch.setChecked(false);


                                        System.out.println(contacto1);
                                        System.out.println(contacto2);


                                        Intent ttt = new Intent(getBaseContext(),Ajuda_Projeto.class);
                                        ttt.putExtra("nome1",d.getName1());
                                        ttt.putExtra("con1",d.getCon1());
                                        ttt.putExtra("nome2",d.getName2());
                                        ttt.putExtra("con2",d.getCont2());
                                        ttt.putExtra("palavra",d.getPalavra());
                                        startActivity(ttt);
                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                    */


                ler1();
                //Button.setText("COMECAR");
                stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));
                aSwitch.setChecked(false);

                System.out.println(contacto1);
                System.out.println(contacto2);

                Intent ttt = new Intent(getBaseContext(),Ajuda_Projeto.class);
                ttt.putExtra("nome1",nome1);
                ttt.putExtra("con1",contacto1);
                ttt.putExtra("nome2",nome2);
                ttt.putExtra("con2",contacto2);
                ttt.putExtra("palavra",palavra);
                startActivity(ttt);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);

            }else{
                showSettingsAlert1();
            }
        });

    }

    public void tt(){
        firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
        String p = "Local";
        databaseReference = firebaseDatabase.getReference(p);

        databaseReference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                LateLOng event = dataSnapshot.getValue(LateLOng.class);
                double la = event.getLatitude();
                double lo = event.getLongitude();
                System.out.println(la);

                if(ver(la,lo)){
                    sql.execSQL("INSERT INTO INFO VALUES('"+la+"', '"+lo+"');");
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) { }
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) { }
            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) { }
            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });

    }

    public boolean ver(double h,double i){
        try(Cursor c = sql.rawQuery("SELECT * FROM INFO ", null)){
            boolean conteudo = c.moveToFirst();
            System.out.println(conteudo);
            while (conteudo) {
                double s = c.getDouble(0);
                double s1 = c.getDouble(1);
                conteudo = c.moveToNext();

                if(h == s && i == s1){
                    return false;
                }
            }
        }catch(RuntimeException e){
            System.out.println("deu erro");
        }
        return true;
    }



    public void ler(){
        try(Cursor c = sql.rawQuery("SELECT * FROM INFO ", null)){
            boolean conteudo = c.moveToFirst();
            //System.out.println(conteudo);
            while (conteudo) {
                double s = c.getDouble(0);
                double s1 = c.getDouble(1);
                result.add(new LatLng(s, s1));
                result1.add(new LateLOng(s,s1));
                conteudo = c.moveToNext();
                //System.out.println(conteudo);
            }
            //System.out.println(result);
        }catch(RuntimeException e){
            System.out.println(e);
        }
    }


    public void ler1(){
        System.out.println("=====");
        try(Cursor c = sql.rawQuery("SELECT * FROM INFOUSERR ", null)){
            boolean conteudo = c.moveToFirst();
            while (conteudo) {
                String s = c.getString(0);
                Double s1 = c.getDouble(1);
                String s2 = c.getString(2);
                Double s3 = c.getDouble(3);
                String s4 = c.getString(4);

                System.out.println("ola");


                //Double k = Double.parseDouble(s1);
                //System.out.println(s1);
                //System.out.println("+"+ Double.valueOf(s1).longValue());

                //contacto1 = "+" + Double.valueOf(s1).longValue();
                //contacto2 = "+" + Double.valueOf(s3).longValue();
                contacto1 = Double.valueOf(s1).longValue();
                contacto2 = Double.valueOf(s3).longValue();
                nome1 = s;
                nome2 = s2;
                palavra = s4;

                System.out.println(contacto1);
                System.out.println(contacto2);

/*
                a.setPalavra(s4);
                a.setName2(s2);
                a.setName1(s);
                a.setCon1(s1);
                a.setCont2(s3);
                System.out.println("------------------------------------------");
                System.out.println(a);
*/

                conteudo = c.moveToNext();
                //System.out.println(conteudo);
            }
            //System.out.println(result);
        }catch(RuntimeException e){
            System.out.println(e);
        }
    }

    public void getLocation(){
        gpsTracker = new GpsTracker(MainActivity.this);
        if(gpsTracker.canGetLocation()){
            latitude = gpsTracker.getLatitude();
            longitude = gpsTracker.getLongitude();
        }else{
            gpsTracker.showSettingsAlert();
        }
    }


    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Deseja sair?")
                .setCancelable(false)
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        //Button.setText("COMECAR");
                        stopService(new Intent(getBaseContext(), Servico_Notificacoes.class));

                        Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        startActivity(intent);
                        //finishAndRemoveTask();
                    }
                })
                .setNegativeButton("Nao", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }

    public void goatras(){
        onBackPressed();
    }

    @Override
    public void finish() {
        onBackPressed();
    }

}