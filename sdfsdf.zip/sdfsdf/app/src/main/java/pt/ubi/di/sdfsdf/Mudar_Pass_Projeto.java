package pt.ubi.di.sdfsdf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Mudar_Pass_Projeto extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    EditText e1,e2,e3;
    Button b1;
    String valor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mudar_pass_projeto);

        e1 = (EditText) findViewById(R.id.edittext);
        e2 = (EditText) findViewById(R.id.edittext5);
        e3 = (EditText) findViewById(R.id.edittext6);
        b1 = (Button) findViewById(R.id.form);

        valor =  (String) getIntent().getSerializableExtra("nome");

    }

    @Override
    protected void onResume() {
        super.onResume();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(e1.getText().toString().equals("") || e2.getText().toString().equals("") ||e3.getText().toString().equals("") ){
                    System.out.println("Insira as credenciais! ou preencha devidamente os contactos");

                    if (e1.getText().toString().equals("")){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        e1.setBackground(gd);
                    }
                    if (e2.getText().toString().equals("") ){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        e2.setBackground(gd);
                    }
                    if (e3.getText().toString().equals("")){
                        GradientDrawable gd = new GradientDrawable();
                        gd.setColor(Color.parseColor("#00ffffff"));
                        gd.setStroke(2,Color.RED);
                        e3.setBackground(gd);
                    }
                }

                else{
                    //verificar credenciais na base de dados
                    String pp = "Users/" + valor;
                    firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");
                    databaseReference = firebaseDatabase.getReference(pp);

                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        boolean verify = true;
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists()){
                                databaseReference.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        Users users = snapshot.getValue(Users.class);

                                        String atual_la = e1.getText().toString();
                                        String h = users.getSal();
                                        byte[] bytes = h.getBytes();

                                        String atual_pass = Hash_Help.getSecurePassword(atual_la, bytes);

                                        String mudar = e2.getText().toString();
                                        String mudar_pass = Hash_Help.getSecurePassword(mudar, bytes);

                                        String mudar2 = e3.getText().toString();
                                        String mudar_pass2 = Hash_Help.getSecurePassword(mudar2, bytes);


                                        System.out.println(atual_pass);
                                        System.out.println(users.getPass());

                                        if(atual_pass.equals(users.getPass())){ //Ver se e igual

                                            if(e2.getText().toString().equals(e3.getText().toString()) && !(mudar_pass.equals(atual_pass)) && !(mudar_pass2.equals(atual_pass)) ){ //ver se e1 dif de e2 e e3
                                                users.setPass(mudar_pass);
                                                addDatatoFirebase(users);
                                            }else if(mudar_pass.equals(atual_pass) || mudar_pass2.equals(atual_pass)){
                                                Toast.makeText(getApplicationContext(), "Não está a alterar a Palavra Passe", Toast.LENGTH_SHORT).show();
                                                GradientDrawable gd = new GradientDrawable();
                                                gd.setColor(Color.parseColor("#00ffffff"));
                                                gd.setStroke(2,Color.RED);
                                                e3.setBackground(gd);

                                                GradientDrawable gdd = new GradientDrawable();
                                                gdd.setColor(Color.parseColor("#00ffffff"));
                                                gdd.setStroke(2,Color.RED);
                                                e2.setBackground(gdd);

                                                GradientDrawable gddd = new GradientDrawable();
                                                gddd.setColor(Color.parseColor("#00ffffff"));
                                                gddd.setStroke(2,Color.WHITE);
                                                e1.setBackground(gddd);
                                            }
                                            else{

                                                Toast.makeText(getApplicationContext(), "Palavras Passes diferem", Toast.LENGTH_SHORT).show();

                                                GradientDrawable gd = new GradientDrawable();
                                                gd.setColor(Color.parseColor("#00ffffff"));
                                                gd.setStroke(2,Color.RED);
                                                e3.setBackground(gd);

                                                GradientDrawable gdd = new GradientDrawable();
                                                gdd.setColor(Color.parseColor("#00ffffff"));
                                                gdd.setStroke(2,Color.RED);
                                                e2.setBackground(gdd);
                                            }
                                        }else{

                                            Toast.makeText(getApplicationContext(), "Palavra Passe Atual não está correta", Toast.LENGTH_SHORT).show();

                                            GradientDrawable gd = new GradientDrawable();
                                            gd.setColor(Color.parseColor("#00ffffff"));
                                            gd.setStroke(2,Color.RED);
                                            e1.setBackground(gd);
                                        }
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                    }
                                });
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }
        });
    }

    private void addDatatoFirebase(Users a) {

        firebaseDatabase = FirebaseDatabase.getInstance("https://sdfsdf-8c438-default-rtdb.europe-west1.firebasedatabase.app");

        String p = "Users/" + a.getNome();
        databaseReference = firebaseDatabase.getReference(p);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                databaseReference.setValue(a);
                Toast.makeText(getApplicationContext(), "Sucesso", Toast.LENGTH_SHORT).show();
                Intent tttt = new Intent(getBaseContext(),Defenicao_Projeto.class);
                startActivity(tttt);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
/*
    public void goatras(View v){
        Intent g = new Intent(this,Menu_Projeto.class);
        startActivity(g);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
*/
    public void goatras(View v){
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}